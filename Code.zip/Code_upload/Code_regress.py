import pandas as pd
import numpy as np

# ============================================================
# Input
# ============================================================
input_csv = r"Example_regress.csv"
output_csv = "Example_regress_results.csv"

# Select one moving windows
target_ecozone = 1   

# Columns
zone_col = "Fid"
target_col = "EVI_De_R"
predictor_cols = ["Spiecerichness", "MAP_BC", "Soil_P"]

# ============================================================
# Load data
# ============================================================
data = pd.read_csv(input_csv, usecols=predictor_cols + [target_col, zone_col])

# Keep one ecozone and remove missing values
df = data[data[zone_col] == target_ecozone].dropna()

# ============================================================
# Calculate standardized single-factor coefficients
# ============================================================
# In simple regression with standardized variables,
# the coefficient equals the Pearson correlation coefficient.
coef = df[predictor_cols].corrwith(df[target_col])

# Identify the dominant factor
dominant_factor = coef.abs().idxmax()
dominant_coef = coef[dominant_factor]

# ============================================================
# Save result
# ============================================================
result = pd.DataFrame({
    "ecozone": [target_ecozone],
    "Dominant_Factor": [dominant_factor],
    "Standardized_Coefficient": [dominant_coef]
})

result.to_csv(output_csv, index=False)

print(result)
print(f"Result saved to: {output_csv}")