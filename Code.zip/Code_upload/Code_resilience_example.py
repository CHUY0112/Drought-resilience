import numpy as np
import pandas as pd
from dlm_functions import forwardFilteringM, Model

#%% read EVI and Tave_zscore for the example pixel
df = pd.read_csv('Input_dlm_example.csv')
evi = df['EVI'].values
tave = df['Tave_zscore'].values

#%% prepare X and Y for DLM
nonnan_idx = np.argwhere(np.isfinite(evi))[0]
N = evi[nonnan_idx[0]:]
Y = N[1:]-np.nanmean(N)
X = N[:-1]-np.nanmean(N)
tave = tave[(tave.shape[0] - N.shape[0]):]
X = np.column_stack([X,tave[:-1]]) 

#%% run DLM
#rseas:two seasonal cycles
#delta:discounting factor
rseas = [1,2] 
delta = 0.98  
M = Model(Y,X,rseas,delta)
FF = forwardFilteringM(M)

#%% extract results
#sC: variance for the theta estimate
#sm: mean for the theta estimate
#snu: degree of freedom
#slik: model likelihood
#nrow: number of theta estimates
#0:mean, 1:trend, 2:lag-1 autocorrelation of EVI
#3:EVI sentivitity to Tave
#4:seasonal cycle 1, 5:seasonal cycle 1
#6:seasonal cycle 2, 7:seasonal cycle 2
nrow = 8
sC = np.zeros((nrow,evi.shape[0])) + np.nan
sm = np.zeros((nrow,evi.shape[0])) + np.nan
snu = np.zeros(evi.shape[0]) + np.nan
slik = np.zeros(evi.shape[0]) + np.nan
psC = np.zeros((FF.get('sC').shape[0],FF.get('sC').shape[2]))
for jj in np.arange(FF.get('sC').shape[2]):
    psC[:,jj] = np.diag(FF.get('sC')[:,:,jj])             
psm = FF.get('sm')
psnu = FF.get('snu')
pslik = FF.get('slik')
sC[0:psm.shape[0], nonnan_idx[0]:] = psC
sm[0:psm.shape[0], nonnan_idx[0]:] = psm
snu[nonnan_idx[0]:] = psnu
slik[nonnan_idx[0]:] = pslik

#%% save results as *.npy files
np.save('../Data/Output/sC.npy', sC)
np.save('../Data/Output/sm.npy', sm)
np.save('../Data/Output/snu.npy', snu)
np.save('../Data/Output/slik.npy', slik)