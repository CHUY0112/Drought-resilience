import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.inspection import partial_dependence

# ============================================================
# Prepare predictors and target
# ============================================================
target_col = "EVI_De_R"

# Remove target variable from predictors
x = data.drop(columns=[target_col])
y = data[target_col]

# Optional: keep only numeric predictors
x = x.select_dtypes(include="number")

# Remove rows with missing values
df = pd.concat([x, y], axis=1).dropna()
x = df.drop(columns=[target_col])
y = df[target_col]

# ============================================================
# Fit random forest model
# ============================================================
model_RF = RandomForestRegressor(
    n_estimators=800,
    min_samples_leaf=3,
    random_state=100,
    n_jobs=-1
)

model_RF.fit(x, y)

# ============================================================
# Calculate PDP values for each feature
# ============================================================
result_data = {}

for feature in x.columns:
    pdp = partial_dependence(
        model_RF,
        x,
        features=[feature],
        grid_resolution=100
    )

    df_pdp = pd.DataFrame({
        "X": pdp["grid_values"][0],
        "PartialDependence": pdp["average"][0]
    })

    result_data[feature] = df_pdp

print("PDP calculation completed.")